package common.util;

import java.sql.*;

public class DBUtil {

		static String url="jdbc:oracle:thin:@localhost:1521:xe";
		static String user="mydev";
		static String pwd="tiger";
	
	
		static{
			//static initializer : main ()�޼ҵ� ���ٵ� ���� ���� �ϴ� ����
			//���⼭ ����Ŭ ����̹��� �ε��Ű��.
			//System.out.println("stactic block");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loading Success!");
		}catch(ClassNotFoundException e) {
			System.out.println("Driver Loading Fail..: ");
			e.printStackTrace();
		}
			
		}
		
		public static Connection getcon() throws java.sql.SQLException{
			Connection con=DriverManager.getConnection(url,user,pwd);
			return con;
		}
		
		//public static void main(String[] args) {
			//System.out.println("main()");}
		
}
