package my.memo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/MemoEditEnd")
public class MemoEditEndServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8");
		PrintWriter out=res.getWriter();
		//1.post��� �ѱ�ó��
		req.setCharacterEncoding("UTF-8");

		//2.����ڰ� ������ �� �ޱ�
		String name=req.getParameter("name");
		String msg=req.getParameter("msg");
		String num=req.getParameter("idx");

		//3. ��ȿ�� üũ
		if(name==null||msg==null||num==null||name.trim().isEmpty()||msg.trim().isEmpty()||num.trim().isEmpty())
		{ 	res.sendRedirect("MemoList");
		
			
			return;
		}
		int idx=Integer.parseInt(num.trim());
		//4.MemoVo�� ������ �� ����
		MemoVo memo=new MemoVo(idx,name,msg,null);
		
		//5.MemoDao�� updateMemo(memo)ȣ��
		MemoDAO dao=new MemoDAO();
		String str="", loc="";
		int n=0;
		try {
			n=dao.updateMemo(memo);
			System.out.println("n=="+n);
		} catch (SQLException e) {
			e.printStackTrace();
			out.println(e);
		}
		//n=0;
		str=(n>0)? "��ϼ���":"��Ͻ���";
		loc=(n>0)? "MemoList":"javascript:history.back()";
	
		out.println("<script>");
		out.println("alert('"+str+"')");
		out.println("location.href='"+loc+"'");
		out.println("</script>");
		out.close();
	}

}
