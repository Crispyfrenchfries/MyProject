package my.memo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemoInsertServlet
 */
@WebServlet("/MemoInsert")
public class MemoInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		process(req,res);
	}

	
	private void process(HttpServletRequest req, HttpServletResponse res) 
	throws ServletException,IOException
	{
		res.setContentType("text/html; charset=UTF-8");
		PrintWriter out=res.getWriter();
		out.println("MemoInsert");
		//1.����ڰ� �Է��� �� �ޱ�
		String name=req.getParameter("name");
		String msg=req.getParameter("msg");
		out.println(name+"/"+msg);
		
		//2.��ȿ�� üũ
		if(name==null||msg==null||name.trim().isEmpty()||msg.trim().isEmpty()) {
			res.sendRedirect("memo/input.html");
			return;
		}
		//3. MemoVo��ü�� ����ڰ� �Է��� �� �����ϱ�
		MemoVo memo=new MemoVo(0,name,msg,null);
		
		//4.MemoDAO�� insertMemo()ȣ��
		MemoDAO dao=new MemoDAO();
		String str="", loc="";
		try {
			int n=dao.insertMemo(memo);
			str=(n>0)? "��ϼ���":"��Ͻ���";
			loc=(n>0)? "MemoList":"memo/input.html";
		} catch (SQLException e) {
			
			e.printStackTrace();
			str=e.getMessage();
		}
		//5.�� ������ �޽��� �����ֱ��� ������ �̵�
		out.println("<script type='text/javascript'>");
		out.println("alert('"+str+"')");
		out.println("location.href='"+loc+"'");
		out.println("</script>");
		out.close();
		
	}


	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		process(req,res);
	}

}
