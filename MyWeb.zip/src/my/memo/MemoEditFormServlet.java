package my.memo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemoEditFormServlet
 */
@WebServlet("/MemoEdit")
public class MemoEditFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8");
		PrintWriter out = res.getWriter();
		out.println(
				"<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\">");
		out.println(
				"<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\">");
		out.println(
				"<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\"></script>");
		out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\"></script>");
		out.println("<div class='container'>");
		//������ �۹�ȣ �ޱ�
		String idxStr=req.getParameter("idx");
		if(idxStr==null|idxStr.trim().isEmpty()) {
			res.sendRedirect("MemoList");
			return;
		}
		int idx=Integer.parseInt(idxStr.trim());
		MemoDAO dao=new MemoDAO();
		try {
			MemoVo memo=dao.selectMemoByIdx(idx);
			out.println(memo);
			if(memo==null) {
				out.println("<script>");
				out.println("alert('�������� �ʴ� ���Դϴ�')");
				out.println("history.back()");//�Ѵܰ� ���� ���̤������̵�
				out.println("</script>");
				return;
			}
	
		
		out.println("<h1 class=\"text-primary mt-5 mb-5 text-center\">::���� �޸��� ����::</h1>");
		out.println("<form name=\"f\" method='post' action=\"MemoEditEnd\">");
		
		out.println("<table class=\"table table-bordered\">");
		out.println("<tr><td class=\"text-center\"><h4>�۹�ȣ</h4></td>");
		out.println("<td><input type=\"text\"  readonly name=\"idx\"value='"+memo.getIdx()+"'");
		
		out.println("class=\"form-control\" ></td></tr>");
		out.println("<tr><td class=\"text-center\"><h4>�ۼ���</h4></td>");
		out.println("<td><input type=\"text\" name=\"name\"value='"+memo.getName()+"'\"");
		out.println("class=\"form-control\" ></td></tr>");
		
		out.println("<tr><td class=\"text-center\"><h4>�޸𳻿�</h4></td>");
		out.println("<td><input type=\"text\" name=\"msg\" value='"+memo.getMsg()+"' ");
		out.println("class=\"form-control\" ></td></tr>");
		
		out.println("<tr><td colspan='2' class='text-right'><button class='btn btn-info'>�����ϱ�</button>");
		out.println("</td></tr>");

		out.println("</table>");
		out.println("</div>");
	
	} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			out.close();
		}
	}

}
