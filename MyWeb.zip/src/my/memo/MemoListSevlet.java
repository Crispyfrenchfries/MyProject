package my.memo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemoListSevlet
 */
@WebServlet("/MemoList")
public class MemoListSevlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8");
		PrintWriter out=res.getWriter();
		out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\">");
		out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\">");
		out.println("<script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js\"></script>");
		out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\"></script>");
		out.println("<div class='container'>");
		
		out.println("<h1 class='m-5 text-primary text-center'>::���ٸ޸���::</h1>");
		out.println("���ٸ޸���");
		out.println("<table class='table table-striped'>");
		out.println("<tr>");
		out.println("<th>�۹�ȣ</th><th>�޸𳻿�</th><th>�ۼ���</th><th>����</th>");
		out.println("</th>");
		
		
		
		
		MemoDAO dao=new MemoDAO();
		try {
			ArrayList<MemoVo> arr=dao.listMemo();
		if(arr!=null) {
			for(MemoVo m:arr) {
			out.println("<tr>");
			out.println("<td>"+m.getIdx()+"</td>");
			out.println("<td>"+m.getMsg()+" ["+m.getWdate()+"]</td>");
			out.println("<td>"+m.getName()+"</td>");
			out.println("<td><a class='btn btn-success' href='MemoDelete?idx="+m.getIdx()+"'>����</a>");
			out.println("<a class='btn btn-warning' href='MemoEdit?idx="+m.getIdx()+"'>����</a>");
			out.println("</td>");
			out.println("</tr>");
			
			}//for======
		}//====if====
		
		out.println("</table>");
		out.println("</div>");
		} catch (SQLException e) {
			e.printStackTrace();
			out.println(e);
		}finally {
		
		out.close();
		
			}
		
		}

}
