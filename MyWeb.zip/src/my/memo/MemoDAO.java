package my.memo;

import java.sql.*;
import java.util.*;
import common.util.*;

public class MemoDAO {

	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;

	public MemoDAO() {
	}

	/** 메모�??�� ?��록하?�� 메소?�� */
	public int insertMemo(MemoVo memo) throws SQLException {
		try {
			con = DBUtil.getcon();
			String sql = "INSERT INTO memo VALUES(memo_seq.nextval,?,?,sysdate)";
			ps = con.prepareStatement(sql);
			ps.setString(1, memo.getName());
			ps.setString(2, memo.getMsg());

			int n = ps.executeUpdate();
			return n;
		} finally {
			close();
		}
	}

	/** 모든 메모�??�� �??��?��?�� 메소?�� -select�? ?��?�� */
	public ArrayList<MemoVo> listMemo() throws SQLException {
		try {
			con = DBUtil.getcon();
			String sql = "SELECT * FROM memo ORDER BY idx DESC";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			return makeList(rs);
		} finally {
			close();
		}
	}

	private ArrayList<MemoVo> makeList(ResultSet rs) throws SQLException {
		ArrayList<MemoVo> arr = new ArrayList<>();
		while (rs.next()) {
			int idx = rs.getInt("idx");
			String name = rs.getString("name");
			String msg = rs.getString("msg");
			java.sql.Date wdate = rs.getDate("wdate");
			// record=>MemoVo
			MemoVo memo = new MemoVo(idx, name, msg, wdate);
			////////////
			arr.add(memo);
			////////////
		} // while-----------
		return arr;
	}

	/** 메모�??�� ?��?��?��?�� 메소?�� -pk�? ?��?�� */
	public int deleteMemo(int idx) throws SQLException {
		try {
			con = DBUtil.getcon();
			String sql = "DELETE FROM MEMO WHERE IDX=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, idx);
			int n = ps.executeUpdate();// DML = executeUpdate();
			return n;
		} finally {
			close();
		}
	}

	/** �?번호(pk)�? 메모?��?��?�� �??��?��?�� 메소?�� select */
	public MemoVo selectMemoByIdx(int idx) throws SQLException {
		try {
			con = DBUtil.getcon();
			String sql = "SELECT * FROM memo WHERE idx=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, idx);
			rs = ps.executeQuery();
			ArrayList<MemoVo> arr = makeList(rs);
			if (arr != null && arr.size() == 1) {
				// ?��?�� �??�� 존재?��?���?
				MemoVo memo = arr.get(0);
				return memo;
			}

			return null;
		} finally {
			close();
		}
	}// ------------------------------

	/** 메모�??�� ?��?��처리?��?�� 메소?�� => update문을 ?��?�� */
	public int updateMemo(MemoVo memo) throws SQLException {
		try {
			con = DBUtil.getcon();
			String sql = "update memo set NAME=?, MSG=? where idx=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, memo.getName());
			ps.setString(2, memo.getMsg());
			ps.setInt(3, memo.getIdx());
			int n = ps.executeUpdate();
			return n;
		} finally {
			close();
		}
	}

	/** �??��?��?��?�� ?��?�� �??��?��?�� 메소?�� select�?, where?��?�� like?�� */
	public ArrayList<MemoVo> findMemo(String colType, String keyword) throws SQLException {
		try {
			con = DBUtil.getcon();
			// SELECT *FROM MEMO WHERE MSG LIKE '%?��%';
			String sql = "", colVal = "";
			if (colType.contentEquals("idx")) {
				sql = "SELECT * FROM memo WHERE" + colType + "=?";
				colVal = keyword;
				;
			} else {
				sql = "SELECT * FROM memo WHERE " + colType + " LIKE ?";
				colVal = "%" + keyword + "%";
			}
			System.out.println(sql);
			ps = con.prepareStatement(sql);

			ps.setString(1, colVal);
			rs = ps.executeQuery();
			ArrayList<MemoVo> arr = makeList(rs);
			return arr;

		} finally {

			close();

		}
	}

	/** DB�??�� ?��?��?�� 반납?��?�� 메소?�� */
	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			System.out.println(e);
		}

	}

}/////////////
