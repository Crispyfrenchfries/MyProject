package my.memo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/MemoDelete")
public class MemoDeletSevlete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html; charset=UTF-8");
		PrintWriter out=res.getWriter();
		//1.������ �� ��ȣ �޾ƿ���
		String num=req.getParameter("idx");
		out.println(num);
		//2.��ȿ��üũ(null, ���ڿ�) redirect�ؼ� �̵�
		if(num==null||num.trim().isEmpty()) {
			res.sendRedirect("memo/input.html");
		}
		int idx=Integer.parseInt(num);
		//3.MemoDAO deleteMemo(idx)ȣ��
		MemoDAO dao=new MemoDAO();
		String str="",loc="";
		try {
			int n=dao.deleteMemo(idx);
			str=(n>0)? "��������":"��������";
			loc= "MemoList";
			
		}catch (SQLException e) {
			e.printStackTrace();
			str=e.getMessage();
		}
		//4.�� ��� �޽��� ó�� �� ������ �̵�
		out.println("<script type='text/javascript'>");
		out.println("alert('"+str+"')");
		out.println("location.href='"+loc+"'");
		out.println("</script>");
		out.close();
	}

}
